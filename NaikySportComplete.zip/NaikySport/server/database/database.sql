create database naiky_db;

use naiky_db;

create table product(
  id int(11) not null auto_increment primary key,
  name varchar(180),
  description varchar(255),
  image varchar(200),
  price float not null,
  stock int not null default 0,
  created_at timestamp default current_timestamp
);

describe product;