import {Request,Response} from 'express';
import pool from '../database';

class ProductController{

   public index(req:Request,res:Response){
       pool.query('describe product');
       res.json({text:'Hello from ProductController!'});
   }

   public async create(req:Request,res:Response):Promise<void>{
      console.log(req.body);
      await pool.query('insert into product set ?',[req.body]);
      res.json({message:'Sucessful - Product Created.'});
   }
   
   public async list(req:Request,res:Response){
       const products = await pool.query('select * from product');
       res.json(products);       
   }

   public async delete(req:Request,res:Response):Promise<void>{
     const {id} = req.params;
     await pool.query('delete from product where id=?',[id]);
     res.json({message:'Sucessful - Product removed'});
   }

   public async update(req:Request,res:Response):Promise<void>{
    const {id} = req.params;
    await pool.query('update  product set ?  where id=?',[req.body,id]);
    res.json({message:'Sucessful - Product Updated'});
  } 


}

const productController = new ProductController();
export default productController;
